The code for shape clustering on Tari56 dataset:

ttmain_56.m:

generate initial similarity matrix setCosts, and all junction set, point set for all shapes.


StructureClustering_56.m:

shape clustering by using common structure.

For details, please refer to
  Wei Shen, Yan Wang, Xiang Bai, Hongyuan Wang, Longin Jan Latecki. Shape clustering: Common structure discovery. Pattern Recognition 46(2): 539-550, 2013.
  
If you have any problems, please contact us by wyanny.9@gmail.com.